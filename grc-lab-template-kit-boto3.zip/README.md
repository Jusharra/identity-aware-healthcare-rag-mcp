# GRC Lab Template Kit

A baseline repo for **GRC Engineering** and **DevSecOps** labs with AWS focus (Lambda + CloudFormation) and a portable structure for other clouds.

## Features
- `src/lambda` with modular findings collectors (IAM, SCP, Access Analyzer, CloudTrail, Security Hub)
- Optional AI narrative (Bedrock-ready) and CSV reporting + SES email
- Makefile + scripts for deploy, report, and AWS credential checks
- PyTest unit tests, `flake8` lint, `pre-commit`, GitHub Actions CI
- Two CloudFormation templates: inline (for demos) and prod (separate Lambda artifact)
- Opinionated repo hygiene: CODEOWNERS, CONTRIBUTING, CI

## Quick Start
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pre-commit install
pytest -q
python -m src.lambda.index --report
./scripts/deploy.sh dev
./scripts/run_report.sh
```

## AWS Permissions (Least-Privilege)

Attach these policies to the Lambda execution role (combine with basic logs):
- `deployment/iam-policies/iam-readonly.json`
- `deployment/iam-policies/cloudtrail-readonly.json`
- `deployment/iam-policies/securityhub-readonly.json`
- `deployment/iam-policies/access-analyzer-readonly.json`
- `deployment/iam-policies/lambda-basic-logs.json`

> Tip: Start in a dev account with Security Hub enabled and an analyzer created.
