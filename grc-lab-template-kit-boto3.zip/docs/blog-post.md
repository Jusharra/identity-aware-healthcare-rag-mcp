# How I Built a Vendor Access Review Lab (Template)

- Problem statement
- Architecture
- Findings collectors
- Risk scoring & reporting
- Portfolio tips & next steps
