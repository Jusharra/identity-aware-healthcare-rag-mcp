from . import utils

def run():
    aa = utils.client("accessanalyzer")
    analyzers = aa.list_analyzers(type="ACCOUNT").get("analyzers", [])
    external = 0
    if analyzers:
        arn = analyzers[0]["arn"]
        paginator = aa.get_paginator("list_findings")
        for page in paginator.paginate(analyzerArn=arn, filter={"isPublic":{"eq":["true"]}}):
            external += len(page.get("findings", []))
    return {"analyzers": len(analyzers), "external_findings": external}
