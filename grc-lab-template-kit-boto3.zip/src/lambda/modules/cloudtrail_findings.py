from . import utils

def run():
    ct = utils.client("cloudtrail")
    trails = ct.describe_trails(includeShadowTrails=True).get("trailList", [])
    multi_region = any(t.get("IsMultiRegionTrail") for t in trails)
    log_file_validation = all(t.get("LogFileValidationEnabled", False) for t in trails) if trails else False

    # Check encryption for S3 (KMS key id set)
    s3_encryption = all(bool(t.get("KmsKeyId")) for t in trails) if trails else False

    return {
        "trails_found": len(trails),
        "multi_region_trail": multi_region,
        "log_file_validation": log_file_validation,
        "s3_encryption": s3_encryption,
    }
