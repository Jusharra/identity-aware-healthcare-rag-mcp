from datetime import datetime, timedelta
from . import utils
import boto3

def _list_users():
    iam = utils.client("iam")
    paginator = iam.get_paginator("list_users")
    for page in paginator.paginate():
        for u in page.get("Users", []):
            yield u

def _list_access_keys(user):
    iam = utils.client("iam")
    paginator = iam.get_paginator("list_access_keys")
    for page in paginator.paginate(UserName=user):
        for k in page.get("AccessKeyMetadata", []):
            yield k

def run():
    iam = utils.client("iam")
    users = list(_list_users())
    without_mfa = 0
    inactive_keys = 0
    wildcard_policies = 0

    # Users without MFA
    for u in users:
        mfa = iam.list_mfa_devices(UserName=u["UserName"]).get("MFADevices", [])
        if len(mfa) == 0:
            without_mfa += 1

        # Access keys older than 90d or inactive
        for key in _list_access_keys(u["UserName"]):
            if key["Status"] != "Active":
                inactive_keys += 1
            else:
                age = (datetime.utcnow() - key["CreateDate"].replace(tzinfo=None)).days
                if age > 90:
                    inactive_keys += 1

    # Inline customer-managed policies with wildcards
    paginator = iam.get_paginator("list_policies")
    for page in paginator.paginate(Scope="Local"):
        for p in page.get("Policies", []):
            v = iam.get_policy_version(PolicyArn=p["Arn"], VersionId=p["DefaultVersionId"])["PolicyVersion"]["Document"]
            statements = v["Statement"] if isinstance(v["Statement"], list) else [v["Statement"]]
            for s in statements:
                actions = s.get("Action", [])
                resources = s.get("Resource", [])
                if actions == "*" or resources == "*":
                    wildcard_policies += 1
                else:
                    # Any member equals "*"
                    if (isinstance(actions, list) and any(a == "*" for a in actions)) or                        (isinstance(resources, list) and any(r == "*" for r in resources)):
                        wildcard_policies += 1

    return {
        "users_total": len(users),
        "users_without_mfa": without_mfa,
        "keys_inactive_or_old": inactive_keys,
        "customer_policies_with_wildcards": wildcard_policies,
    }
