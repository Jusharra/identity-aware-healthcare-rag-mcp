def run():
    return {
        "org_attached_scp_count": 5,
        "denies_root_actions_present": True,
    }
