from . import utils

def run():
    sh = utils.client("securityhub")
    # Standards enabled
    standards = sh.describe_standards_controls(StandardsSubscriptionArn=_first_std_arn(sh)).get("Controls", [])
    standards_enabled = _enabled_standard_names(sh)

    # Count open findings
    findings_open = 0
    paginator = sh.get_paginator("get_findings")
    for page in paginator.paginate(
        Filters={
            "RecordState":[{"Value":"ACTIVE","Comparison":"EQUALS"}],
            "WorkflowState":[{"Value":"NEW","Comparison":"EQUALS"}]
        },
        PaginationConfig={"PageSize":100}
    ):
        findings_open += len(page.get("Findings", []))

    return {
        "findings_open": findings_open,
        "standards_enabled": standards_enabled,
        "controls_sample_count": len(standards)
    }

def _first_std_arn(sh):
    subs = sh.get_enabled_standards().get("StandardsSubscriptions", [])
    return subs[0]["StandardsSubscriptionArn"] if subs else ""

def _enabled_standard_names(sh):
    subs = sh.get_enabled_standards().get("StandardsSubscriptions", [])
    names = []
    for s in subs:
        meta = s.get("Standards", {})
        name = meta.get("Name") or s.get("StandardsArn","").split("/")[-1]
        names.append(name)
    return names
