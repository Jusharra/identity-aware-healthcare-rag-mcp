import os
import boto3

def client(service: str, region: str | None = None):
    reg = region or os.getenv("AWS_REGION") or os.getenv("AWS_DEFAULT_REGION") or "us-east-1"
    return boto3.client(service, region_name=reg)

def account_id() -> str:
    return boto3.client("sts").get_caller_identity()["Account"]
