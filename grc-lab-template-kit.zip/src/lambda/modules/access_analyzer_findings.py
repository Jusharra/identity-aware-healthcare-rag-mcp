def run():
    return {
        "analyzers": 1,
        "external_findings": 4,
    }
