def run():
    return {
        "multi_region_trail": True,
        "log_file_validation": True,
        "s3_encryption": True,
    }
