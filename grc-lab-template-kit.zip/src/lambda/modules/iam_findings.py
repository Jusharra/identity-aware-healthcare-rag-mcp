def run():
    return {
        "users_without_mfa": 2,
        "inactive_access_keys": 1,
        "policies_with_wildcards": 3,
    }
