def run():
    return {
        "findings_open": 17,
        "standards_enabled": ["CIS-1.4", "Foundational-Best-Practices"],
    }
